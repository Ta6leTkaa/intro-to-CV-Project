Compile results_checkpoint.tex with tectonic, or run pdflatex twice.
All tables and figures are included. Results and analysis are in English.
